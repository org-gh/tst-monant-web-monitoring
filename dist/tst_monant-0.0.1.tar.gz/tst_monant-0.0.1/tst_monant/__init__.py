# This line of code will allow shorter imports
from tst_monant.badatel import BadatelSpider